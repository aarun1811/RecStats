#!/bin/bash
# RecViz backend — start under nohup. Idempotent.
set -euo pipefail

RECVIZ_ROOT=/opt/rectify/rectrace/recviz
LOGS=$RECVIZ_ROOT/logs
RUN=$RECVIZ_ROOT/run

mkdir -p "$LOGS" "$RUN"

# Load environment from .env
set -a
source "$RECVIZ_ROOT/.env"
set +a

# Oracle Instant Client — required for thick mode.
# Without LD_LIBRARY_PATH, libnnz19.so and other dependent libs can't be found
# and oracledb.init_oracle_client() falls back to thin mode silently.
export LD_LIBRARY_PATH="/opt/oraclient/19.3_64/lib:${LD_LIBRARY_PATH:-}"

if [ -f "$RUN/backend.pid" ] && kill -0 "$(cat "$RUN/backend.pid")" 2>/dev/null; then
    echo "Backend already running (pid $(cat "$RUN/backend.pid"))"
else
    echo "Starting backend on 0.0.0.0:${RECVIZ_PUBLIC_PORT}..."
    cd "$RECVIZ_ROOT/app/backend"
    nohup venv/bin/uvicorn app.main:app \
        --host 0.0.0.0 \
        --port "$RECVIZ_PUBLIC_PORT" \
        --workers 1 \
        --log-level info \
        > "$LOGS/backend.log" 2> "$LOGS/backend.err" &
    echo $! > "$RUN/backend.pid"
    echo "  Backend started (pid $(cat "$RUN/backend.pid"))"

    # Wait up to 30 seconds for /health to respond
    for i in $(seq 1 15); do
        if curl -sf "http://127.0.0.1:${RECVIZ_PUBLIC_PORT}/health" > /dev/null 2>&1; then
            echo "  Backend healthy after ${i}x2 seconds"
            break
        fi
        sleep 2
        if [ "$i" -eq 15 ]; then
            echo "  FAILED -- /health not responding. Check $LOGS/backend.err"
            exit 1
        fi
    done
fi

echo ""
echo "RecViz: http://0.0.0.0:${RECVIZ_PUBLIC_PORT}/"
