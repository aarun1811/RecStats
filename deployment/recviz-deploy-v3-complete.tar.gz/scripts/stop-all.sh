#!/bin/bash
# RecViz backend — stop gracefully, then force if needed.
RUN=/opt/rectify/rectrace/recviz/run
PID_FILE="$RUN/backend.pid"

if [ -f "$PID_FILE" ]; then
    PID=$(cat "$PID_FILE")
    if kill -0 "$PID" 2>/dev/null; then
        echo "Stopping backend (pid $PID)..."
        kill "$PID"
        for i in $(seq 1 10); do
            if ! kill -0 "$PID" 2>/dev/null; then
                echo "  Stopped gracefully"
                break
            fi
            sleep 1
        done
        if kill -0 "$PID" 2>/dev/null; then
            echo "  Force-killing"
            kill -9 "$PID"
        fi
    else
        echo "Backend not running (stale pidfile)"
    fi
    rm -f "$PID_FILE"
else
    echo "Backend: no pidfile"
fi
echo "Done."
