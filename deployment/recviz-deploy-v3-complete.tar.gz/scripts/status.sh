#!/bin/bash
# RecViz backend — show current status.
RECVIZ_ROOT=/opt/rectify/rectrace/recviz
RUN=$RECVIZ_ROOT/run
PORT=$(grep ^RECVIZ_PUBLIC_PORT "$RECVIZ_ROOT/.env" | cut -d= -f2 | tr -d '"')

echo "=== Process ==="
if [ -f "$RUN/backend.pid" ] && kill -0 "$(cat "$RUN/backend.pid")" 2>/dev/null; then
    echo "backend: RUNNING (pid $(cat "$RUN/backend.pid"))"
else
    echo "backend: NOT RUNNING"
fi

echo ""
echo "=== Health checks ==="
curl -sf "http://127.0.0.1:${PORT}/health" > /dev/null && echo "  /health   : OK" || echo "  /health   : FAIL"
curl -sf "http://127.0.0.1:${PORT}/" > /dev/null       && echo "  /         : OK" || echo "  /         : FAIL"
curl -sf "http://127.0.0.1:${PORT}/api/databases" > /dev/null && echo "  /api/*    : OK" || echo "  /api/*    : FAIL"
