"""Tests for the Oracle NUMBER output type handler (Unit 1)."""

from __future__ import annotations

from decimal import Decimal
from unittest.mock import MagicMock

import pytest


def test_int_coercion_for_unscaled_number():
    """NUMBER(18, 0) should materialize as Python int."""
    from app.db.oracle_types import _coerce_number

    # Unscaled int within safe range
    assert _coerce_number(Decimal("42"), precision=18, scale=0) == 42
    assert isinstance(_coerce_number(Decimal("42"), precision=18, scale=0), int)

    # Large but still within 18 digits
    assert _coerce_number(Decimal("123456789012345678"), precision=18, scale=0) == 123456789012345678


def test_float_coercion_for_scaled_number():
    """NUMBER(10, 2) should materialize as Python float."""
    from app.db.oracle_types import _coerce_number

    result = _coerce_number(Decimal("1234.56"), precision=10, scale=2)
    assert isinstance(result, float)
    assert result == pytest.approx(1234.56)


def test_decimal_fallback_for_high_precision():
    """NUMBER(38, 0) exceeds JS safe-integer range, keep as Decimal."""
    from app.db.oracle_types import _coerce_number

    big = Decimal("12345678901234567890")  # 20 digits
    result = _coerce_number(big, precision=38, scale=0)
    assert result == big
    assert isinstance(result, Decimal)


def test_none_value_passes_through():
    """NULL values (None) should pass through unchanged."""
    from app.db.oracle_types import _coerce_number

    assert _coerce_number(None, precision=10, scale=0) is None


def test_unparameterized_number_preserves_decimal():
    """Oracle returns precision=None and scale=None for bare NUMBER columns,
    computed/expression columns, and aggregates. The handler must NOT collapse
    these to int — doing so would silently truncate fractional values like
    Decimal('3.14') to 3. Preserve Decimal instead."""
    from app.db.oracle_types import _coerce_number

    # Critical regression: fractional value with unknown precision/scale
    fractional = Decimal("3.14159")
    assert _coerce_number(fractional, None, None) == fractional
    assert isinstance(_coerce_number(fractional, None, None), Decimal)

    # Half-known shapes — also preserve Decimal
    assert isinstance(_coerce_number(fractional, None, 2), Decimal)
    assert isinstance(_coerce_number(fractional, 10, None), Decimal)

    # Integer value with unknown precision/scale should also preserve Decimal
    # (we don't know if the next row will be fractional).
    integer_like = Decimal("42")
    assert _coerce_number(integer_like, None, None) == integer_like
    assert isinstance(_coerce_number(integer_like, None, None), Decimal)


def test_handler_skips_non_number_columns():
    """The output type handler should return None for VARCHAR2/etc so oracledb
    uses its default type mapping."""
    from app.db.oracle_types import oracle_output_type_handler
    import oracledb

    cursor = MagicMock()

    # VARCHAR2 column — handler should return None (no override)
    metadata = MagicMock()
    metadata.type_code = oracledb.DB_TYPE_VARCHAR
    metadata.name = "NAME"
    metadata.precision = None
    metadata.scale = None
    result = oracle_output_type_handler(cursor, metadata)
    assert result is None


def test_handler_returns_var_for_number_column():
    """For a NUMBER column, the handler should return a cursor.var() with an
    outconverter that actually coerces values end-to-end."""
    from app.db.oracle_types import oracle_output_type_handler
    import oracledb

    cursor = MagicMock()
    cursor.arraysize = 100

    metadata = MagicMock()
    metadata.type_code = oracledb.DB_TYPE_NUMBER
    metadata.name = "AMOUNT"
    metadata.precision = 10
    metadata.scale = 2

    oracle_output_type_handler(cursor, metadata)

    cursor.var.assert_called_once()
    args, kwargs = cursor.var.call_args
    assert args[0] is Decimal or kwargs.get("typ") is Decimal
    assert "outconverter" in kwargs

    # Exercise the outconverter directly: it should coerce Decimal to float
    # for NUMBER(10, 2) — if this fails, we have a per-column closure bug
    # or a misrouted precision/scale capture.
    outconverter = kwargs["outconverter"]
    result = outconverter(Decimal("1234.56"))
    assert isinstance(result, float)
    assert result == pytest.approx(1234.56)


def test_handler_outconverter_preserves_decimal_for_unparameterized_number():
    """Per-column closure must capture metadata.precision=None / scale=None
    and defer to the Decimal fallback (not silently truncate)."""
    from app.db.oracle_types import oracle_output_type_handler
    import oracledb

    cursor = MagicMock()
    cursor.arraysize = 100

    metadata = MagicMock()
    metadata.type_code = oracledb.DB_TYPE_NUMBER
    metadata.name = "COMPUTED"
    metadata.precision = None
    metadata.scale = None

    oracle_output_type_handler(cursor, metadata)

    _, kwargs = cursor.var.call_args
    outconverter = kwargs["outconverter"]

    # Regression guard: an aggregate SUM(amount) with fractional value
    # must NOT truncate to an int.
    fractional = Decimal("3.14159")
    result = outconverter(fractional)
    assert result == fractional
    assert isinstance(result, Decimal)
