"""Tests for the Oracle NUMBER output type handler (Unit 1)."""

from __future__ import annotations

from decimal import Decimal
from unittest.mock import MagicMock

import pytest


def test_int_coercion_for_unscaled_number():
    """NUMBER(18, 0) should materialize as Python int."""
    from app.db.oracle_types import _coerce_number

    # Unscaled int within safe range
    assert _coerce_number(Decimal("42"), precision=18, scale=0) == 42
    assert isinstance(_coerce_number(Decimal("42"), precision=18, scale=0), int)

    # Large but still within 18 digits
    assert _coerce_number(Decimal("123456789012345678"), precision=18, scale=0) == 123456789012345678


def test_float_coercion_for_scaled_number():
    """NUMBER(10, 2) should materialize as Python float."""
    from app.db.oracle_types import _coerce_number

    result = _coerce_number(Decimal("1234.56"), precision=10, scale=2)
    assert isinstance(result, float)
    assert result == pytest.approx(1234.56)


def test_decimal_fallback_for_high_precision():
    """NUMBER(38, 0) exceeds JS safe-integer range, keep as Decimal."""
    from app.db.oracle_types import _coerce_number

    big = Decimal("12345678901234567890")  # 20 digits
    result = _coerce_number(big, precision=38, scale=0)
    assert result == big
    assert isinstance(result, Decimal)


def test_none_value_passes_through():
    """NULL values (None) should pass through unchanged."""
    from app.db.oracle_types import _coerce_number

    assert _coerce_number(None, precision=10, scale=0) is None


def test_unparameterized_number_preserves_decimal():
    """Oracle returns precision=None and scale=None for bare NUMBER columns,
    computed/expression columns, and aggregates. The handler must NOT collapse
    these to int — doing so would silently truncate fractional values like
    Decimal('3.14') to 3. Preserve Decimal instead."""
    from app.db.oracle_types import _coerce_number

    # Critical regression: fractional value with unknown precision/scale
    fractional = Decimal("3.14159")
    assert _coerce_number(fractional, None, None) == fractional
    assert isinstance(_coerce_number(fractional, None, None), Decimal)

    # Half-known shapes — also preserve Decimal
    assert isinstance(_coerce_number(fractional, None, 2), Decimal)
    assert isinstance(_coerce_number(fractional, 10, None), Decimal)

    # Integer value with unknown precision/scale should also preserve Decimal
    # (we don't know if the next row will be fractional).
    integer_like = Decimal("42")
    assert _coerce_number(integer_like, None, None) == integer_like
    assert isinstance(_coerce_number(integer_like, None, None), Decimal)


def test_handler_skips_non_number_columns():
    """The output type handler should return None for VARCHAR2/etc so
    oracledb uses its default type mapping.

    Uses the LEGACY 6-arg signature: (cursor, name, default_type, size,
    precision, scale). This is the signature SQLAlchemy's Oracle dialect
    uses to invoke our handler, not the new 2-arg FetchInfo form."""
    from app.db.oracle_types import oracle_output_type_handler
    import oracledb

    cursor = MagicMock()

    # VARCHAR2 column — handler should return None (no override)
    result = oracle_output_type_handler(
        cursor,
        "NAME",
        oracledb.DB_TYPE_VARCHAR,
        256,
        None,
        None,
    )
    assert result is None


def test_handler_returns_var_for_number_column():
    """For a NUMBER column, the handler should return a cursor.var() with an
    outconverter that actually coerces values end-to-end."""
    from app.db.oracle_types import oracle_output_type_handler
    import oracledb

    cursor = MagicMock()
    cursor.arraysize = 100

    oracle_output_type_handler(
        cursor,
        "AMOUNT",
        oracledb.DB_TYPE_NUMBER,
        None,
        10,
        2,
    )

    cursor.var.assert_called_once()
    args, kwargs = cursor.var.call_args
    assert args[0] is Decimal or kwargs.get("typ") is Decimal
    assert "outconverter" in kwargs

    # Exercise the outconverter directly: it should coerce Decimal to float
    # for NUMBER(10, 2) — if this fails, we have a per-column closure bug
    # or a misrouted precision/scale capture.
    outconverter = kwargs["outconverter"]
    result = outconverter(Decimal("1234.56"))
    assert isinstance(result, float)
    assert result == pytest.approx(1234.56)


def test_handler_outconverter_preserves_decimal_for_unparameterized_number():
    """Per-column closure must capture precision=None / scale=None and
    defer to the Decimal fallback (not silently truncate)."""
    from app.db.oracle_types import oracle_output_type_handler
    import oracledb

    cursor = MagicMock()
    cursor.arraysize = 100

    oracle_output_type_handler(
        cursor,
        "COMPUTED",
        oracledb.DB_TYPE_NUMBER,
        None,
        None,
        None,
    )

    _, kwargs = cursor.var.call_args
    outconverter = kwargs["outconverter"]

    # Regression guard: an aggregate SUM(amount) with fractional value
    # must NOT truncate to an int.
    fractional = Decimal("3.14159")
    result = outconverter(fractional)
    assert result == fractional
    assert isinstance(result, Decimal)


def test_handler_uses_legacy_6_arg_signature_for_sqlalchemy_compat():
    """REGRESSION: SQLAlchemy's Oracle dialect (cx_oracle.py) installs its
    own output_type_handler wrapper on every new connection. The wrapper
    captures our handler as a 'default_handler' and invokes it with the
    LEGACY 6-arg signature:

        default_handler(cursor, name, default_type, size, precision, scale)

    Previous v7 implementation used the 2-arg (cursor, FetchInfo) form,
    which python-oracledb 2.0+ also supports, but SQLAlchemy's wrapper
    still uses the legacy form. Production Oracle 19c crashed at the
    first query with:

        TypeError: oracle_output_type_handler() takes 2 positional
        arguments but 6 were given

    at sqlalchemy/dialects/oracle/cx_oracle.py:934. This test simulates
    SQLAlchemy's exact call pattern and locks in the 6-arg contract.
    """
    from app.db.oracle_types import oracle_output_type_handler
    import inspect
    import oracledb

    # 1. Signature check: the handler MUST accept 6 positional args.
    sig = inspect.signature(oracle_output_type_handler)
    positional = [
        p for p in sig.parameters.values()
        if p.kind in (inspect.Parameter.POSITIONAL_ONLY,
                      inspect.Parameter.POSITIONAL_OR_KEYWORD)
    ]
    assert len(positional) == 6, (
        f"Handler must accept 6 positional args for SQLAlchemy Oracle dialect "
        f"compatibility, got {len(positional)}: {[p.name for p in positional]}"
    )

    # 2. Call as SQLAlchemy's cx_oracle.py does: 6 positional args.
    cursor = MagicMock()
    cursor.arraysize = 100

    # NUMBER column path — should return a cursor.var
    result = oracle_output_type_handler(
        cursor,          # cursor
        "AMOUNT",        # name
        oracledb.DB_TYPE_NUMBER,  # default_type
        None,            # size
        10,              # precision
        2,               # scale
    )
    assert result is not None  # var returned for NUMBER

    # VARCHAR column path — should return None (no override)
    cursor2 = MagicMock()
    result2 = oracle_output_type_handler(
        cursor2,
        "NAME",
        oracledb.DB_TYPE_VARCHAR,
        256,
        None,
        None,
    )
    assert result2 is None
    cursor2.var.assert_not_called()


def test_install_handler_skips_non_oracle_engine_without_error(monkeypatch):
    """Passing a non-Oracle engine (e.g. Postgres dev stack) must early-return
    without raising. This is the path exercised by db/engine.py at module
    load time when RECVIZ_DB_URL points to Postgres."""
    from app.db import oracle_types

    # Use a plain class, not MagicMock — MagicMock auto-vivifies any
    # attribute access, which defeats assertions about the dialect guard.
    class _FakePostgresEngine:
        dialect = type("D", (), {"name": "postgresql"})()

    fake_engine = _FakePostgresEngine()

    # Stub event.listens_for so we can detect unwanted listener attachment.
    calls = []

    def _fake_listens_for(target, event_name):  # noqa: ARG001
        def _decorator(fn):
            calls.append((target, event_name))
            return fn

        return _decorator

    monkeypatch.setattr(oracle_types.event, "listens_for", _fake_listens_for)

    # Must not raise.
    oracle_types.install_oracle_number_handler(fake_engine)

    # Must not have attached a listener (non-Oracle dialect early-returns).
    assert calls == []


def test_install_handler_does_not_crash_on_oracle_engine_without_info_attribute(
    monkeypatch,
):
    """REGRESSION: the initial v7 implementation used engine.info.get(...) to
    track idempotency, but SQLAlchemy's Engine class does not have an .info
    attribute (only Connection does). On production Oracle 19c this raised
    AttributeError at backend startup from db/engine.py's module-level call.

    This test constructs an Engine-like object with dialect.name='oracle' and
    NO .info attribute, and verifies install_oracle_number_handler runs
    cleanly without AttributeError. SQLite test engines mask this bug because
    they early-return on the dialect check.
    """
    from app.db import oracle_types

    # Minimal fake engine: dialect.name is 'oracle', no .info attribute,
    # arbitrary attribute assignment works (standard Python object).
    class _FakeOracleEngine:
        def __init__(self):
            self.dialect = MagicMock()
            self.dialect.name = "oracle"
            self._listeners_attached = 0

    fake_engine = _FakeOracleEngine()

    # Stub event.listens_for so we don't need the real SQLAlchemy event
    # dispatcher (which requires a proper Engine). The stub records that
    # a listener would have been attached.
    def _fake_listens_for(target, event_name):  # noqa: ARG001
        def _decorator(fn):
            target._listeners_attached += 1
            return fn

        return _decorator

    monkeypatch.setattr(oracle_types.event, "listens_for", _fake_listens_for)

    # Must not raise AttributeError on engine.info or anything else.
    oracle_types.install_oracle_number_handler(fake_engine)

    # Verify the listener path actually executed (not early-returned).
    assert fake_engine._listeners_attached == 1
    # Verify the idempotency sentinel was set via setattr.
    assert getattr(fake_engine, "_recviz_oracle_number_handler_installed", False)

    # Second call must be a no-op (idempotent) — no new listener attached.
    oracle_types.install_oracle_number_handler(fake_engine)
    assert fake_engine._listeners_attached == 1
