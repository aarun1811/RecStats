"""Tests for UTC datetime normalization in CamelModel (Unit 2)."""

from __future__ import annotations

from datetime import datetime, timezone

from app.models.base import CamelModel


class _Inner(CamelModel):
    ts: datetime


class _Outer(CamelModel):
    name: str
    created_at: datetime
    inner: _Inner | None = None


def test_naive_datetime_normalized_to_utc_aware():
    """A naive datetime on a CamelModel field should be made UTC-aware."""
    naive = datetime(2026, 4, 11, 13, 27, 0)
    model = _Outer(name="x", created_at=naive)

    assert model.created_at.tzinfo is not None
    assert model.created_at.tzinfo == timezone.utc


def test_already_aware_datetime_is_preserved():
    """A tz-aware datetime should pass through unchanged."""
    # Create a UTC-aware dt; the validator should leave it alone
    aware = datetime(2026, 4, 11, 13, 27, 0, tzinfo=timezone.utc)
    model = _Outer(name="x", created_at=aware)

    assert model.created_at == aware
    assert model.created_at.tzinfo == timezone.utc


def test_serialized_json_contains_offset():
    """model_dump_json should emit the offset marker, not a naive ISO string."""
    naive = datetime(2026, 4, 11, 13, 27, 0)
    model = _Outer(name="x", created_at=naive)

    json_str = model.model_dump_json()

    # Accept either "+00:00" or "Z" as a valid UTC offset marker.
    assert "+00:00" in json_str or "Z" in json_str, (
        f"Expected UTC offset marker in JSON, got: {json_str}"
    )
    # And make sure the bare naive ISO format is NOT present.
    assert '"2026-04-11T13:27:00"' not in json_str


def test_nested_model_datetime_also_normalized():
    """A nested CamelModel's datetime should also be normalized (each nested
    model runs its own validator)."""
    inner = _Inner(ts=datetime(2026, 4, 11, 13, 27, 0))
    outer = _Outer(
        name="x",
        created_at=datetime(2026, 4, 11, 13, 27, 0),
        inner=inner,
    )

    assert outer.inner is not None
    assert outer.inner.ts.tzinfo == timezone.utc
    assert outer.created_at.tzinfo == timezone.utc


def test_model_validate_json_also_normalizes():
    """FastAPI's request parsing goes through model_validate_json, which is a
    different code path than __init__. Ensure the validator runs there too —
    a future Pydantic upgrade could silently regress this and we'd never
    notice without this test."""
    payload = '{"name": "x", "createdAt": "2026-04-11T13:27:00"}'
    model = _Outer.model_validate_json(payload)

    assert model.created_at.tzinfo is not None
    assert model.created_at.tzinfo == timezone.utc
