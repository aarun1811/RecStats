"""Base Pydantic model with camelCase aliasing and UTC datetime normalization."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, model_validator
from pydantic.alias_generators import to_camel


class CamelModel(BaseModel):
    """Base class for every RecViz request/response model.

    Provides:
    - camelCase alias generation (``created_at`` <-> ``createdAt``)
    - ``populate_by_name=True`` so both snake_case and camelCase work on input
    - UTC datetime normalization via a model validator that replaces naive
      datetime field values with UTC-aware equivalents. This assumes every
      naive datetime in the system is conceptually UTC, which is true for
      RecViz -- ``datetime.now(timezone.utc)`` is used throughout Python
      code, and Oracle TIMESTAMP WITH TIME ZONE round-trips may drop
      ``tzinfo`` under some oracledb + SQLAlchemy configurations, leaving
      naive datetimes at the Pydantic boundary. Without this coercion,
      the default Pydantic ISO serializer emits naive strings (no ``+00:00``
      suffix) and the frontend parses them as local time, which causes
      "5 hours ago" drift for a just-saved row on an IST deployment.
    """

    model_config = {"alias_generator": to_camel, "populate_by_name": True}

    @model_validator(mode="after")
    def _normalize_naive_datetimes_to_utc(self) -> "CamelModel":
        """Replace any naive datetime field values with UTC-aware equivalents.

        Runs automatically on every model instantiation via ``__init__``,
        ``model_validate``, and ``model_validate_json``. Only touches fields
        whose current value is a ``datetime`` with ``tzinfo is None``.
        Non-datetime fields and tz-aware datetimes are left alone.

        Nested CamelModel fields run their own validator, so we do NOT
        recurse manually.

        **Limitation:** collection-typed datetime fields (``list[datetime]``,
        ``dict[str, datetime]``, etc.) are NOT recursed into. Today no
        response model exposes such a field; if you add one, normalize the
        values explicitly in a custom field_validator on that model.
        """
        for field_name in type(self).model_fields:
            current: Any = getattr(self, field_name, None)
            if isinstance(current, datetime) and current.tzinfo is None:
                object.__setattr__(
                    self, field_name, current.replace(tzinfo=timezone.utc)
                )
        return self
