"""Oracle NUMBER output type handler.

Oracle's NUMBER type is an arbitrary-precision decimal. python-oracledb's
default behavior is to return NUMBER values as Python ``Decimal`` objects
to preserve precision. But ``Decimal`` is not JSON-native — Pydantic
serializes it to a JSON *string*, which breaks downstream type-checking
in the frontend (e.g. KPI builder filters columns by
``typeof v === 'number'``).

This module provides an ``oracledb`` output type handler that converts
NUMBER columns to native Python ``int`` or ``float`` when it is safe to
do so without losing precision:

- ``NUMBER(p, 0)`` with ``p <= 18`` --> ``int`` (Oracle max precision is
  38 digits; 18 is a conservative bound near JavaScript
  ``Number.MAX_SAFE_INTEGER`` of 2^53 ~= 9e15 ~= 16 digits, with a
  2-digit buffer so integer IDs and counts coerce cleanly)
- ``NUMBER(p, s)`` with ``s > 0`` and ``p - s <= 15`` --> ``float``
- otherwise --> leave as ``Decimal`` (falls back to string in JSON)

Registered via a SQLAlchemy ``connect`` event listener in
``db/engine.py`` (metadata engine) and ``services/engine_manager.py``
(data-source engines). Only installed when the SQLAlchemy dialect is
``oracle``; no-op on Postgres.
"""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Any

import oracledb
from sqlalchemy import event

logger = logging.getLogger(__name__)

# JavaScript Number.MAX_SAFE_INTEGER = 2^53 - 1 = 9_007_199_254_740_991
# That is ~16 decimal digits. We use 18 as the cutoff for unscaled ints
# (2-digit safety buffer below Oracle's NUMBER(38) max). Rows that land
# above the cutoff remain Decimal and will JSON-serialize as strings,
# which is correct for high-precision IDs that cannot survive float64.
_MAX_SAFE_UNSCALED_PRECISION = 18

# For scaled NUMBER(p, s), the total significant digits before + after
# the decimal point must fit IEEE 754 double (15 significant digits).
_MAX_SAFE_FLOAT_SIGNIFICANT_DIGITS = 15


def _coerce_number(
    value: Any,
    precision: int | None,
    scale: int | None,
) -> Any:
    """Coerce a single NUMBER column value to int/float when safe.

    Called once per fetched value by the output type handler's
    ``outconverter`` callback.

    CRITICAL: Oracle returns ``precision=None`` and ``scale=None`` for
    unparameterized ``NUMBER`` columns — bare ``NUMBER`` declarations,
    computed columns (``SELECT amount * 1.1 FROM ...``), aggregates
    (``SUM``, ``AVG``), and some legacy schemas. We CANNOT coerce these
    to int because a fractional value like ``Decimal("3.14")`` would
    silently truncate to ``3``. Fall back to Decimal whenever either
    precision or scale is unknown.
    """
    if value is None:
        return None
    if not isinstance(value, Decimal):
        # Already coerced by the driver (shouldn't happen with our handler
        # setup, but be defensive).
        return value

    if precision is None or scale is None:
        # Unparameterized NUMBER — precision/scale unknown. Preserve
        # Decimal to avoid silently truncating fractional values.
        return value

    p, s = precision, scale

    if s == 0 and p <= _MAX_SAFE_UNSCALED_PRECISION:
        return int(value)
    if s > 0 and p <= _MAX_SAFE_FLOAT_SIGNIFICANT_DIGITS:
        # Total significant digits (p) fits IEEE 754 double precision
        # (15 significant digits). Float coercion is safe.
        return float(value)
    # Out of safe range — preserve Decimal. Pydantic will render as string.
    return value


def oracle_output_type_handler(cursor: Any, metadata: Any) -> Any:
    """oracledb output type handler that remaps NUMBER columns.

    oracledb 2.0+ handler signature: the driver calls this once per
    fetched column with the cursor and a ``FetchInfo`` metadata object
    that exposes ``type_code``, ``precision``, ``scale``, ``name``,
    etc. Returning a new cursor variable replaces oracledb's default
    materialization for that column.

    Returns a ``cursor.var(Decimal, outconverter=...)`` for NUMBER
    columns so each fetched value is coerced via ``_coerce_number``.
    Returns ``None`` for every other column type, which tells oracledb
    to use its default mapping.

    Registered by assigning to ``connection.outputtypehandler`` on
    every new oracledb connection (see ``install_oracle_number_handler``).
    """
    if metadata.type_code != oracledb.DB_TYPE_NUMBER:
        return None

    # Snapshot precision/scale per column so the closure below captures
    # per-column values (not the last column's values from the enclosing
    # handler invocation).
    col_precision = metadata.precision
    col_scale = metadata.scale

    return cursor.var(
        Decimal,
        arraysize=cursor.arraysize,
        outconverter=lambda v: _coerce_number(v, col_precision, col_scale),
    )


_HANDLER_INSTALLED_KEY = "_recviz_oracle_number_handler_installed"


def install_oracle_number_handler(engine: Any) -> None:
    """Attach a ``connect`` listener that sets the output type handler on
    every new oracledb connection from this engine.

    Idempotent: a second call on the same engine is a no-op. Uses
    ``engine.info`` (a SQLAlchemy-provided per-engine dict) to track
    whether the listener has already been attached.

    Only operates on Oracle engines. If called with a non-Oracle engine,
    logs at debug level and returns without wiring anything.
    """
    if engine.dialect.name != "oracle":
        logger.debug(
            "install_oracle_number_handler: skipping non-Oracle engine (dialect=%s)",
            engine.dialect.name,
        )
        return

    if engine.info.get(_HANDLER_INSTALLED_KEY):
        logger.debug(
            "install_oracle_number_handler: handler already installed on engine %r",
            engine,
        )
        return

    @event.listens_for(engine, "connect")
    def _set_outputtypehandler(dbapi_conn, connection_record):  # noqa: ARG001
        try:
            dbapi_conn.outputtypehandler = oracle_output_type_handler
        except Exception as exc:  # noqa: BLE001 - best-effort
            logger.warning(
                "Failed to install Oracle NUMBER output type handler: %s", exc
            )

    engine.info[_HANDLER_INSTALLED_KEY] = True
