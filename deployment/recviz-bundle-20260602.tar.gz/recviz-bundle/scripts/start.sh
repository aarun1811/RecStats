#!/usr/bin/env bash
# RecViz launch script — runs the FastAPI app with uvicorn on port 8000.
#
# Usage (from the unpacked recviz-bundle/ directory):
#   ./scripts/start.sh
#
# Prereqs (run once after unpacking):
#   python -m venv venv
#   source venv/bin/activate    # Git Bash on Windows / bash on RHEL
#   pip install -r backend/requirements.txt
#   cp backend/.env.citi.example .env  &&  edit .env with real values
#
# Activate the venv yourself before running this script (so PYTHONPATH /
# virtualenv binaries are first on PATH). This script does NOT activate
# the venv for you — it just sources .env and exec's uvicorn.

set -euo pipefail

# Resolve script + project root regardless of where it's invoked from.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

# Load .env if present (project-root relative). set -a auto-exports
# everything declared in .env to child processes.
ENV_FILE="${RECVIZ_ENV_FILE:-$PROJECT_ROOT/.env}"
if [ ! -f "$ENV_FILE" ]; then
  echo "ERROR: env file not found at $ENV_FILE" >&2
  echo "Copy backend/.env.citi.example to .env at the project root and fill in <CITI_*> values." >&2
  exit 1
fi
set -a
# shellcheck disable=SC1090
. "$ENV_FILE"
set +a

# Sanity checks — fail loud rather than ship a half-configured boot.
: "${RECVIZ_DB_URL:?RECVIZ_DB_URL is required (set in .env)}"
: "${ORACLE_CLIENT_LIB_DIR:?ORACLE_CLIENT_LIB_DIR is required (set in .env)}"
: "${RECVIZ_ENCRYPTION_KEY:?RECVIZ_ENCRYPTION_KEY is required (set in .env)}"

# Verify uvicorn is on PATH (activated venv) before exec.
if ! command -v uvicorn >/dev/null 2>&1; then
  echo "ERROR: uvicorn not on PATH. Activate the venv first:" >&2
  echo "  source venv/bin/activate     (Git Bash / bash)" >&2
  echo "  .\\venv\\Scripts\\Activate.ps1 (PowerShell)" >&2
  exit 1
fi

HOST="${RECVIZ_HOST:-0.0.0.0}"
PORT="${RECVIZ_PORT:-8000}"

cd "$PROJECT_ROOT/backend"
echo "Starting RecViz on http://${HOST}:${PORT} (project root: $PROJECT_ROOT)"
exec uvicorn app.main:app --host "$HOST" --port "$PORT"
