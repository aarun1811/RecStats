RecViz Citi laptop bundle
=========================

Contents:
  backend/app/             FastAPI app source
  backend/requirements.txt Python deps
  backend/.env.citi.example Env template (placeholder values)
  frontend/dist/           Pre-built React bundle (Vite output)
  scripts/start.sh         Launch script — runs uvicorn
  README.txt               This file
  CITI-LAPTOP-SETUP.md     Full setup guide

Quick start (run from the unpacked recviz-bundle/ directory):

  1. Create + activate Python venv:
       python -m venv venv
       source venv/bin/activate          # Git Bash on Windows / bash on RHEL
       # OR (PowerShell):  .\venv\Scripts\Activate.ps1

  2. Install Python deps:
       pip install -r backend/requirements.txt

  3. Create .env from the template:
       cp backend/.env.citi.example .env
     Then edit .env and fill in every <CITI_*> placeholder:
       - RECVIZ_DB_URL          Citi Oracle JDBC URL with user/password
       - RECVIZ_DB_SCHEMA       Citi RecViz schema owner
       - ORACLE_CLIENT_LIB_DIR  Path to Oracle Instant Client (Windows: C:/oracle/instantclient_21_x)
       - RECVIZ_ENCRYPTION_KEY  Generate ONCE with:
         python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"

  4. Launch:
       ./scripts/start.sh

     Open http://localhost:8000/ — RecViz UI renders from the bundled
     frontend/dist/. Health check: http://localhost:8000/health.

Notes:
  - The bundle does NOT include a venv (platform mismatch — you must
    create one fresh on each target machine).
  - Tables in Citi are assumed to already exist (recviz_dashboards,
    recviz_connections, recviz_datasets, recviz_kpis). The seed script
    and alembic migrations are NOT bundled — see the RecViz repo if you
    later need to bootstrap a fresh Citi schema.
  - Once running, point the dash-tlm-stats + dash-quickrec-stats
    connections at Citi Oracle either via the Admin UI or by editing
    recviz_connections rows. See CITI-LAPTOP-SETUP.md step 6 for both
    approaches.

For full setup notes (Oracle Instant Client install, port-collision
with rectrace, Windows-specific gotchas), read CITI-LAPTOP-SETUP.md.
